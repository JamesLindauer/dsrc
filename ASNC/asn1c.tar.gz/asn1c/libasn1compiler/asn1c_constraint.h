#ifndef	ASN1C_CONSTRAINT_H
#define	ASN1C_CONSTRAINT_H

int asn1c_emit_constraint_checking_code(arg_t *arg);

#endif	/* ASN1C_CONSTRAINT_H */
